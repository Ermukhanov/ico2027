Case archive: inspect metadata as well as members.
